#!/bin/bash
while :; do
  node index.js
  echo "restarting"
done